angular.module('app')
.config(function($routeProvider){
	$routeProvider
    .when("/", {
        templateUrl : "views/home.html"
    })
    .when("/admission", {
        templateUrl : "views/admission.html",
		controller : "admissionCtrl"
    })
    .when("/edit", {
        templateUrl : "views/Edit.html",
		controller : "editCtrl"
    })
    .when("/View", {
        templateUrl : "views/view.html",
		controller : "viewCtrl"
    });
});