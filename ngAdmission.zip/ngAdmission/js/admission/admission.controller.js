angular.module('app').controller("admissionCtrl",["$scope","admission", function ($scope,admission){
    $scope.formData = {};	
	$scope.formData.name="";
	$scope.submit = function() {
		console.log('formData',$scope.formData);
		var student = _.extend($scope.formData,{});
		$scope.formData = null;
		admission.setdata(student);
	}; 
	
}]);

angular.module('app').controller("editCtrl",  ["$scope","admission", function($scope, admission){
	$scope.getStudentDetails = getStudentDetails;
	$scope.students = admission.getData();
	$scope.student = null;
	function getStudentDetails(){
		$scope.student = _.find($scope.students,function(s){
			if(s.name== $scope.selectedStudent )
				return s;
		});
	}
}]);

angular.module('app').controller("viewCtrl", ["$scope","admission", function($scope, admission){
    $scope.students = admission.getData();
}]);


angular.module('app').directive('myDirective', function () {
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {
            scope.$watch(attrs.ngModel, function (v) {
            if(v =="")
            {
              element.css("background-color", "#ffffff");
            }
            else{
                element.css("background-color", "yellow");
            }
                console.log('value changed, new value is: ' + v);
                
            });
        }
    };
});

