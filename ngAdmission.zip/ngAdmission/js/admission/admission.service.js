angular.module('app').factory('admission', function(){
	var add = this;
	
	add.listOfStudents = [];
	
	add.setdata= function(student){
		add.listOfStudents.push(student);
		console.log('no of students', add.listOfStudents);
	};
	
	add.getData = function(){
		return add.listOfStudents;
	};
	
	return add;
});