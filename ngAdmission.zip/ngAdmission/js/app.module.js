angular.module('app.core',['ngRoute']);

angular.module('app',['app.core']);

