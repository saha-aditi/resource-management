'use strict';

(function($){

  $(function() {

  var datascource = {
      'id': '1',
      'name': 'Lao Lao',
      'title': 'general manager',
	 'troncAssocInBand' : true, 
      'children': [
        { 'id': '2', 'name': 'Bo Miao', 'title': 'department manager', 'troncAssocInBand' : true ,'className': 'level'},
        { 'id': '3', 'name': 'Su Miao', 'title': 'department manager', 'troncAssocInBand' : true ,'className': 'middle-level', 
          'children': [
            { 'id': '4', 'name': 'Tie Hua', 'title': 'senior engineer','troncAssocInBand' : true ,'className': 'level' },
            { 'id': '5', 'name': 'Hei Hei', 'title': 'senior engineer', 'troncAssocInBand' : true,'className': 'level', 
              'children': [
                { 'id': '6', 'name': 'Pang Pang', 'title': 'engineer', 'troncAssocInBand' : false,'className': 'level'  },
                { 'id': '7', 'name': 'Xiang Xiang', 'title': 'UE engineer','troncAssocInBand' : true,'className': 'level'  }
              ]
            }
          ]
        },
        { 'id': '8', 'name': 'Yu Jie', 'title': 'department manager','troncAssocInBand' : true ,'className': 'level' },
        { 'id': '9', 'name': 'Yu Li', 'title': 'department manager','troncAssocInBand' : false ,'className': 'level' },
        { 'id': '10', 'name': 'Hong Miao', 'title': 'department manager','troncAssocInBand' : true,'className': 'level'  },
        { 'id': '11', 'name': 'Yu Wei', 'title': 'department manager','troncAssocInBand' : true ,'className': 'level' },
        { 'id': '12', 'name': 'Chun Miao', 'title': 'department manager','troncAssocInBand' : false,'className': 'level'  },
        { 'id': '13', 'name': 'Yu Tie', 'title': 'department manager','troncAssocInBand' : true ,'className': 'level' }
      ]
    };

     $('#chart-container').orgchart({
      'data' : datascource,
      'depth': 2,
      'nodeContent': 'title',
      'nodeID': 'id',
      'createNode': function($node, data) {
		if(data.troncAssocInBand){
		  var secondMenuIcon = $('<i>', {
          'class': 'fa fa-user-secret second-menu-icon icon-color',
          click: function() {
            
			$(this).siblings('.second-menu').toggle();
          }
        });
		var troncAssociates=[{'name':'John Doe','dept':'TM'},{'name':'Willium Vicent Karguetta','dept':'PMO De Contai El Salvadora'},{'name':'Martin Sun Guptill','dept':'DESS'}];
		var count=0;
		
		var assocText = '<div class="tronc-base-div">'
		
		$.each(troncAssociates, function (key, value) {
            //name = value.name; value.name
			assocText = assocText + '<div class="tronc-assoc">'
						+ '<div  class="modal-header_bgColor modal-header-color">'+value.name+'</div>'
						+ '<div>'+value.dept+'</div>'
						+ '</div>';
            count++;
        });
		assocText = assocText + '</div>';
		
        var secondMenu = '<div class="second-menu"> <div class="modal-content "><div class="modal-header modal-header_bgColor"> <h4 class="modal-title modal-header-color">Tronc Associates sharing band with '+ data.name +'</h4></div><div class="modal-body">'+assocText +'</div></div></div>';
        $node.append(secondMenuIcon).append(secondMenu);
}
      }
    });

  });

})(jQuery);